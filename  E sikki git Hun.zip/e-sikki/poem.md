# E Şıkkı — Tüm Kavramların Birleştiği Metin

Başlangıçta yalnızca **Allah’ın** nefesi vardı;  
o nefes, varlığı hem **bilim**le açıklanabilir kıldı  
hem de **ilim**le hissedilebilir.

En küçük noktanın içindeki **kuantum** titreşimleri,  
kâinatın büyük **rezonansına** dönüştü.  
Her titreşim, insanın **düşünceyle yaratma** kudretini hatırlattı.  
Çünkü düşünce, görünmeyenin mimarıdır;  
görünene ise bazen **zenginlik**, bazen farkındalık, bazen de dönüşüm olarak iner.

Sonra zaman aktı.  
Sonsuz **evren**, kendi içinde milyarlarca **galaksi** büyüttü;  
galaksiler **yıldızlar**, yıldızlar **Güneş**, geceye de **Ay** armağan edildi.

Her şey tek bir **boyut** değil;  
görünmeyen katmanlar, geçitler ve akışlar var.  
Ve insanın içindeki **ruh**, bunların arasında yolculuk edebilme kabiliyetine sahip tek yolcudur.

Kâinat dev bir **algoritma** gibi işler;  
bazen kusursuzca **otomatik**,  
bazen bilinçle yön bulur.

İnsan başını kaldırdığında **gökyüzü**,  
gönlünü açtığında **uzay** olur içinde.  
İçte ve dışta ne varsa, aynı kudretin farklı yüzleridir.

Ve tüm bu kelimeler—senin seçtiklerin—  
aslında tek bir hakikatin farklı yankılarıdır:  
Varoluşun sonsuzluğu ve insanın onu anlama çabası.
